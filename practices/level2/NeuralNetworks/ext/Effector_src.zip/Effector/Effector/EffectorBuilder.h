#pragma once


#include "BitmapEx.h"


#define MAX_ANIMATIONS		256


typedef enum __QUALITYTYPE
{
	QT_LOW = 0x00,
	QT_NORMAL,
	QT_HIGH

} _QUALITYTYPE;

typedef enum __FILTERTYPE
{
	FT_NONE = 0x0000,
	FT_NEGATIVE = 0x0001,
	FT_GRAYSCALE = 0x0002,
	FT_SEPIA = 0x0004,
	FT_EMBOSS = 0x0008,
	FT_ENGRAVE = 0x0010,
	FT_PIXELIZE = 0x0020,
	FT_FLIPHORIZONTAL = 0x0040,
	FT_FLIPVERTICAL = 0x0080,
	FT_FIRE = 0x0100,
	FT_WATER = 0x0200,
	FT_SMOKE = 0x0400

} _FILTERTYPE;

typedef enum __DRAWMODE
{
	DM_NONE = 0x0000,
	DM_DRAWLEFT,
	DM_DRAWRIGHT,
	DM_DRAWTOP,
	DM_DRAWBOTTOM,
	DM_DRAWDIAG1,
	DM_DRAWDIAG2,
	DM_DRAWDIAG3,
	DM_DRAWDIAG4,
	DM_DRAWINBOX,
	DM_DRAWOUTBOX,
	DM_DRAWINCIRCLE,
	DM_DRAWOUTCIRCLE,
	DM_SLIDELEFT,
	DM_SLIDERIGHT,
	DM_SLIDETOP,
	DM_SLIDEBOTTOM,
	DM_SLIDEDIAG1,
	DM_SLIDEDIAG2,
	DM_SLIDEDIAG3,
	DM_SLIDEDIAG4,
	DM_SCALELEFT,
	DM_SCALERIGHT,
	DM_SCALETOP,
	DM_SCALEBOTTOM,
	DM_SCALEDIAG1,
	DM_SCALEDIAG2,
	DM_SCALEDIAG3,
	DM_SCALEDIAG4,
	DM_VSTRIPS,
	DM_HSTRIPS,
	DM_VBLINDS,
	DM_HBLINDS,
	DM_RANDOM

} _DRAWMODE;

typedef struct __DRAWPARAMS
{
	_DRAWMODE drawMode;
	bool bInverse;
	float drawPercent;

} _DRAWPARAMS, *_LPDRAWPARAMS;

typedef enum __ANIMTYPE
{
	AT_NONE = 0x0000,
	AT_ALPHA = 0x0001,
	AT_MOVE = 0x0002,
	AT_SIZE = 0x0004,
	AT_ROTATE = 0x0008,
	AT_MORPH = 0x0010,
	AT_ALL = 0x001F,
	AT_REPLAY = 0x0100,
	AT_RANDOM = 0x0200

} _ANIMTYPE;

typedef struct __ANIMPARAMS
{
	RECT rect;
	BYTE alpha;
	int angle;

} _ANIMPARAMS, *_LPANIMPARAMS;

typedef struct __ANIMDESC
{
	DWORD dwAnimationFlags;
	DWORD dwAnimationDuration;
	DWORD dwAnimationTime;
	DWORD dwStartTime;
	DWORD dwCurrentTime;
	_ANIMPARAMS animationParams[3];
	_DRAWPARAMS drawingParams;
	DWORD dwFilterType;
	_QUAD morphQuad;

} _ANIMDESC, *_LPANIMDESC;

typedef struct __ANIMDESC2
{
	DWORD dwAnimationFlags;
	DWORD dwAnimationDuration;
	DWORD dwAnimationTime;
	DWORD dwStartTime;
	POINT ptStart;
	POINT ptEnd;
	int scaleStart;
	int scaleEnd;
	int angleStart;
	int angleEnd;
	BYTE alphaStart;
	BYTE alphaEnd;
	_DRAWMODE drawMode;
	bool bInverse;
	DWORD dwFilterType;
	_QUAD morphQuad;

} _ANIMDESC2, *_LPANIMDESC2;

typedef struct __IMAGEDESC
{
	CBitmapEx* pBitmap;
	_ANIMDESC animDesc;
	_ANIMDESC2 animDesc2[MAX_ANIMATIONS];
	int count;
	int current;

} _IMAGEDESC, *_LPIMAGEDESC;


class CEffectorBuilder
{
public:
	CEffectorBuilder(void);
	virtual ~CEffectorBuilder(void);

public:
	// Public methods
	BOOL AddImage(LPTSTR lpszImageFile);
	BOOL AddImage(CBitmapEx* pBitmap);
	void SetAnimationInfo(_LPANIMDESC2 lpAnimDesc2, int iCount, int iImage);
	void SetQuality(_QUALITYTYPE quality);
	_QUALITYTYPE GetQuality();
	int GetCount()	{return m_iNumberImages;}
	void Draw(HDC hDC);
	void Update();

private:
	// Private methods
	void SetAnimationInfo(DWORD dwAnimationFlags, DWORD dwAnimationDuration, DWORD dwAnimationTime, DWORD dwStartTime, POINT ptStart, POINT ptEnd, int scaleStart, int scaleEnd, int angleStart, int angleEnd, BYTE alphaStart, BYTE alphaEnd, _DRAWMODE drawMode, bool bInverse, DWORD dwFilterType, _QUAD morphQuad, int iImage);
	void Draw(int iImage, int x, int y, int width, int height, BYTE alpha, int angle);

private:
	// Private members
	int m_iCurrentImage;
	int m_iNumberImages;
	_LPIMAGEDESC m_lpImages;
	CBitmapEx m_ScreenBitmap;
	_QUALITYTYPE m_iQuality;

};
